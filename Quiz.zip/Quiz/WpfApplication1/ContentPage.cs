﻿namespace WpfApplication1
{
    public class ContentPage
    {

    }
}